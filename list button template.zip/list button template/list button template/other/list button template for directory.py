import tkinter
import os

def DoSomething(Directory):
    print(str("you click the : ") + Directory)

def ForgetallButton():
    for x in range(0,len(ButtonList)):
        ButtonList[x].grid_forget()

def ChangePrintPageNumber():
    global PageNumber
    global PrintPageNumber
    PrintPageNumber = str(PageNumber+1) + "/" + str(int(len(ButtonList)/10))
    PageNumberLable.configure(text=PrintPageNumber)

def ChangePage():
    for x in range(0,10):
        ButtonList[x+(PageNumber*10)].grid(column=0,row=x)

def LastPage():
    global PageNumber
    global PrintPageNumber
    PageNumber -= 1
    
    if PageNumber < 0:
        PageNumber = 0
    
    ForgetallButton()
    ChangePrintPageNumber()
    ChangePage()


def NextPage():
    global PageNumber
    global PrintPageNumber
    PageNumber += 1

    MaxPageNumber = int(len(ButtonList)/10)-1
    if PageNumber >= MaxPageNumber:
        PageNumber = MaxPageNumber

    ForgetallButton()
    ChangePrintPageNumber()
    ChangePage()
 
 
#####   main   #####
ButtonList = []
PageNumber = 0
window = tkinter.Tk()
window.geometry("295x530")
window.title("list button template")

frame1 = tkinter.Frame(master=window, width=295, height=80, bg="blue",relief=tkinter.SUNKEN,borderwidth = 20)
frame1.pack()

LastButton = tkinter.Button(master=frame1, text="Last", width=9, borderwidth=5, command=LastPage)
NextButton = tkinter.Button(master=frame1, text="Next", width=9, borderwidth=5, command=NextPage)

LastButton.pack(padx=5, pady=5,side=tkinter.LEFT)
NextButton.pack(padx=5, pady=5,side=tkinter.RIGHT) 

frame2 = tkinter.Frame(master=window, width=295, height=450, bg="black",relief=tkinter.GROOVE,borderwidth = 20)
frame2.pack()


# get directory
MyDirectory = os.popen("dir /b /a:d")
MyDirectory = MyDirectory.read()
MyDirectoryList = MyDirectory.split("\n") 
MyDirectoryList.pop(-1)

for x in MyDirectoryList:
    Button = tkinter.Button(frame2, text=x, width=35, height=2, bg="yellow", command=lambda x=x:DoSomething(x)) # , bg="yellow"
    ButtonList.append(Button)


# null
for x in range(len(ButtonList)%10,10):
    NoneButton = tkinter.Button(frame2, text="", width=35, height=2, bg="black")
    ButtonList.append(NoneButton)
    

for x in range(0,10):
    ButtonList[x].grid(column=0,row=x)

PrintPageNumber = str(PageNumber+1) + "/" + str(int(len(ButtonList)/10))

PageNumberLable = tkinter.Label(master=frame1, text=PrintPageNumber, width=8, borderwidth=5)
PageNumberLable.pack(padx=5, pady=5, side="bottom") 

window.mainloop()